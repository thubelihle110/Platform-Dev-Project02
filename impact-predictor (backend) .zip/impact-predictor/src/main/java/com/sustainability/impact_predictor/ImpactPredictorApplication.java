package com.sustainability.impact_predictor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImpactPredictorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImpactPredictorApplication.class, args);
	}

}
