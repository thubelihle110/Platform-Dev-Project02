package com.sustainability.impact_predictor.models;

import java.util.Map;

public class PredictionResult {
    private Map<Integer, PredictionMetric> metrics;
    private double confidenceScore;
    private String recommendation;
    private boolean targetMet;
    
    public PredictionResult() {}
    
    public PredictionResult(Map<Integer, PredictionMetric> metrics, double confidenceScore, 
                           String recommendation, boolean targetMet) {
        this.metrics = metrics;
        this.confidenceScore = confidenceScore;
        this.recommendation = recommendation;
        this.targetMet = targetMet;
    }
    
    public static PredictionResult insufficientData() {
        PredictionResult result = new PredictionResult();
        result.setConfidenceScore(0.3);
        result.setRecommendation("Insufficient data for reliable prediction. Need at least 3 months of post-intervention data.");
        result.setTargetMet(false);
        result.setMetrics(Map.of());
        return result;
    }
    
    // Getters and Setters
    public Map<Integer, PredictionMetric> getMetrics() { return metrics; }
    public void setMetrics(Map<Integer, PredictionMetric> metrics) { this.metrics = metrics; }
    
    public double getConfidenceScore() { return confidenceScore; }
    public void setConfidenceScore(double confidenceScore) { this.confidenceScore = confidenceScore; }
    
    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
    
    public boolean isTargetMet() { return targetMet; }
    public void setTargetMet(boolean targetMet) { this.targetMet = targetMet; }
}
