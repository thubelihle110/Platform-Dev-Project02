package com.sustainability.impact_predictor.services;

import com.sustainability.impact_predictor.models.*;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PredictionService {
   
    private static final double CO2_FACTOR = 0.00052; // tons CO2 per kWh (South Africa grid)
    private static final double COST_PER_KWH = 2.50; // R per kWh
    
    public PredictionResult predictProjectImpact(Project project, List<Reading> readings) {
        if (readings.size() < 3) {
            return PredictionResult.insufficientData();
        }
        
        // Separate pre and post intervention data
        LocalDate interventionDate = project.getStartDate();
        List<Reading> baselineReadings = readings.stream()
            .filter(r -> r.getDate().isBefore(interventionDate))
            .sorted(Comparator.comparing(Reading::getDate))
            .collect(Collectors.toList());
            
        List<Reading> postReadings = readings.stream()
            .filter(r -> !r.getDate().isBefore(interventionDate))
            .sorted(Comparator.comparing(Reading::getDate))
            .collect(Collectors.toList());
        
        // 1. Baseline model (linear regression on pre-project data)
        double baselineTrend = calculateBaselineTrend(baselineReadings);
        
        // 2. Impact model (exponential smoothing with trend)
        double currentTrend = calculateCurrentTrend(postReadings);
        
        // 3. Generate predictions for 3, 6, 12 months
        Map<Integer, Double> kwhPredictions = generatePredictions(postReadings, currentTrend, 12);
        
        // 4. Calculate savings vs baseline
        Map<Integer, PredictionMetric> metrics = new HashMap<>();
        for (int months : Arrays.asList(3, 6, 12)) {
            Double predictedKwh = kwhPredictions.get(months);
            Double baselineKwh = project.getBaselineKwh() + (baselineTrend * months);
            Double kwhSaved = baselineKwh - predictedKwh;
            
            PredictionMetric metric = new PredictionMetric();
            metric.setMonths(months);
            metric.setPredictedKwh(predictedKwh);
            metric.setKwhSaved(Math.max(0, kwhSaved));
            metric.setCo2eAvoided(kwhSaved * CO2_FACTOR);
            metric.setCostSaved(kwhSaved * COST_PER_KWH);
            metric.setPercentVsBaseline((predictedKwh / baselineKwh - 1) * 100);
            
            metrics.put(months, metric);
        }
        
        // 5. Calculate confidence score based on data quality and consistency
        double confidenceScore = calculateConfidenceScore(readings, postReadings);
        
        // 6. Generate recommendation
        String recommendation = generateRecommendation(project, metrics, confidenceScore);
        
        // 7. Check if target will be met
        boolean targetMet = checkTargetMet(project, metrics.get(12).getPredictedKwh());
        
        return new PredictionResult(metrics, confidenceScore, recommendation, targetMet);
    }
    
    private double calculateBaselineTrend(List<Reading> readings) {
        if (readings.size() < 2) return 0;
        
        int n = readings.size();
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        
        for (int i = 0; i < n; i++) {
            double x = i;
            double y = readings.get(i).getKwhUsed();
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumX2 += x * x;
        }
        
        double slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        return slope; // Monthly change in baseline
    }
    
    private double calculateCurrentTrend(List<Reading> readings) {
        if (readings.size() < 2) return 0;
        
        // Exponential smoothing with alpha = 0.3
        double alpha = 0.3;
        double[] smoothed = new double[readings.size()];
        smoothed[0] = readings.get(0).getKwhUsed();
        
        for (int i = 1; i < readings.size(); i++) {
            smoothed[i] = alpha * readings.get(i).getKwhUsed() + (1 - alpha) * smoothed[i-1];
        }
        
        // Calculate average monthly change in smoothed values
        double totalChange = 0;
        for (int i = readings.size() - 3; i < readings.size() - 1 && i >= 0; i++) {
            totalChange += (smoothed[i+1] - smoothed[i]);
        }
        
        return totalChange / Math.min(3, readings.size() - 1);
    }
    
    private Map<Integer, Double> generatePredictions(List<Reading> readings, double trend, int months) {
        Map<Integer, Double> predictions = new HashMap<>();
        double lastValue = readings.get(readings.size() - 1).getKwhUsed();
        
        for (int m = 1; m <= months; m++) {
            double predicted = lastValue + (trend * m);
            // Apply seasonality factor (simple monthly pattern)
            double seasonality = 1 + Math.sin(m * Math.PI / 6) * 0.05;
            predicted = predicted * seasonality;
            predictions.put(m, Math.max(0, predicted));
        }
        
        return predictions;
    }
    
    private double calculateConfidenceScore(List<Reading> allReadings, List<Reading> postReadings) {
        double score = 0.8; // Base confidence
        
        // Data volume factor
        if (allReadings.size() > 12) score += 0.1;
        else if (allReadings.size() > 6) score += 0.05;
        else if (allReadings.size() < 3) score -= 0.3;
        
        // Post-intervention data factor
        if (postReadings.size() > 6) score += 0.05;
        else if (postReadings.size() < 3) score -= 0.2;
        
        // Consistency factor (low variance = higher confidence)
        if (postReadings.size() >= 3) {
            double variance = calculateVariance(postReadings);
            if (variance < 100) score += 0.05;
            else if (variance > 1000) score -= 0.1;
        }
        
        return Math.min(0.99, Math.max(0.3, score));
    }
    
    private double calculateVariance(List<Reading> readings) {
        double mean = readings.stream().mapToDouble(Reading::getKwhUsed).average().orElse(0);
        double variance = readings.stream()
            .mapToDouble(r -> Math.pow(r.getKwhUsed() - mean, 2))
            .average().orElse(0);
        return variance;
    }
    
    private String generateRecommendation(Project project, Map<Integer, PredictionMetric> metrics, double confidence) {
        PredictionMetric threeMonth = metrics.get(3);
        PredictionMetric sixMonth = metrics.get(6);
        PredictionMetric twelveMonth = metrics.get(12);
        
        if (confidence < 0.6) {
            return "Gathering more data - check back after " + 
                   (project.getReadings().size() < 6 ? "3" : "2") + 
                   " more meter readings for more accurate predictions.";
        }
        
        double savingsRate = threeMonth.getKwhSaved() / 3; // Monthly savings rate
        double progressToTarget = (project.getBaselineKwh() - twelveMonth.getPredictedKwh()) / 
                                  (project.getBaselineKwh() - project.getTargetKwh());
        
        if (progressToTarget > 1.1) {
            return String.format("🏆 Excellent progress! At current rate, target will be exceeded by %.0f%%. " +
                               "Consider reallocating %.0f%% of budget to other buildings for maximum campus impact.",
                               (progressToTarget - 1) * 100, Math.min(30, (progressToTarget - 1) * 50));
        } else if (progressToTarget > 0.9) {
            return String.format("✅ On track to meet target. Current savings rate: %.0f kWh/month. " +
                               "Increase rollout speed by 10%% to exceed target by 2 months.",
                               savingsRate);
        } else if (progressToTarget > 0.7) {
            return String.format("⚠️ Slightly behind target. Current rate: %.0f kWh/month vs needed: %.0f kWh/month. " +
                               "Recommend checking for implementation delays or equipment issues.",
                               savingsRate, (project.getBaselineKwh() - project.getTargetKwh()) / 
                               ChronoUnit.MONTHS.between(LocalDate.now(), project.getTargetDate()));
        } else {
            double remainingBudget = project.getBudget() - project.getBudgetUsed();
            double projectedShortfall = (project.getTargetKwh() - twelveMonth.getPredictedKwh()) * COST_PER_KWH;
            
            return String.format("🚨 Critical: Only %.0f%% of target progress at %.0f%% budget used. " +
                               "Forecast shows R%.0f shortfall by target date. Immediate intervention recommended.",
                               progressToTarget * 100, 
                               (project.getBudgetUsed() / project.getBudget()) * 100,
                               Math.max(0, projectedShortfall));
        }
    }
    
    private boolean checkTargetMet(Project project, double predictedKwh) {
        return predictedKwh <= project.getTargetKwh();
    }
}
