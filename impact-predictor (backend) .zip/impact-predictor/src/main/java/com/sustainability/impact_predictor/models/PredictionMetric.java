package com.sustainability.impact_predictor.models;

public class PredictionMetric {
    private int months;
    private Double predictedKwh;
    private Double kwhSaved;
    private Double co2eAvoided;
    private Double costSaved;
    private Double percentVsBaseline;
    
    public PredictionMetric() {}
    
    public PredictionMetric(int months, Double predictedKwh, Double kwhSaved, 
                           Double co2eAvoided, Double costSaved, Double percentVsBaseline) {
        this.months = months;
        this.predictedKwh = predictedKwh;
        this.kwhSaved = kwhSaved;
        this.co2eAvoided = co2eAvoided;
        this.costSaved = costSaved;
        this.percentVsBaseline = percentVsBaseline;
    }
    
    // Getters and Setters
    public int getMonths() { return months; }
    public void setMonths(int months) { this.months = months; }
    
    public Double getPredictedKwh() { return predictedKwh; }
    public void setPredictedKwh(Double predictedKwh) { this.predictedKwh = predictedKwh; }
    
    public Double getKwhSaved() { return kwhSaved; }
    public void setKwhSaved(Double kwhSaved) { this.kwhSaved = kwhSaved; }
    
    public Double getCo2eAvoided() { return co2eAvoided; }
    public void setCo2eAvoided(Double co2eAvoided) { this.co2eAvoided = co2eAvoided; }
    
    public Double getCostSaved() { return costSaved; }
    public void setCostSaved(Double costSaved) { this.costSaved = costSaved; }
    
    public Double getPercentVsBaseline() { return percentVsBaseline; }
    public void setPercentVsBaseline(Double percentVsBaseline) { this.percentVsBaseline = percentVsBaseline; }
}
