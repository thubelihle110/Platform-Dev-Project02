package com.sustainability.impact_predictor.models;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Project {
  @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String category;
    private Double baselineKwh;
    private Double targetKwh;
    private LocalDate targetDate;
    private LocalDate startDate;
    private Double budget;
    private Double budgetUsed;
    private String interventionType;
    
    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
    private List<Reading> readings = new ArrayList<>();
    
    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public Double getBaselineKwh() { return baselineKwh; }
    public void setBaselineKwh(Double baselineKwh) { this.baselineKwh = baselineKwh; }
    public Double getTargetKwh() { return targetKwh; }
    public void setTargetKwh(Double targetKwh) { this.targetKwh = targetKwh; }
    public LocalDate getTargetDate() { return targetDate; }
    public void setTargetDate(LocalDate targetDate) { this.targetDate = targetDate; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public Double getBudget() { return budget; }
    public void setBudget(Double budget) { this.budget = budget; }
    public Double getBudgetUsed() { return budgetUsed; }
    public void setBudgetUsed(Double budgetUsed) { this.budgetUsed = budgetUsed; }
    public String getInterventionType() { return interventionType; }
    public void setInterventionType(String interventionType) { this.interventionType = interventionType; }
    public List<Reading> getReadings() { return readings; }
    public void setReadings(List<Reading> readings) { this.readings = readings; }
}
