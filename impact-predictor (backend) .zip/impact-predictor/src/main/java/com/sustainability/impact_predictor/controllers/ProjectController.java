package com.sustainability.impact_predictor.controllers;

import com.sustainability.impact_predictor.models.*;
import com.sustainability.impact_predictor.services.PredictionService;
import com.sustainability.impact_predictor.repositories.ProjectRepository;
import com.sustainability.impact_predictor.repositories.ReadingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/projects")
@CrossOrigin(origins = "*", allowedHeaders = "*", 
             methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, 
                        RequestMethod.DELETE, RequestMethod.OPTIONS})
public class ProjectController {
    
    @Autowired
    private ProjectRepository projectRepository;
    
    @Autowired
    private ReadingRepository readingRepository;
    
    @Autowired
    private PredictionService predictionService;
    
    // GET all projects
    @GetMapping
    public ResponseEntity<List<Project>> getAllProjects() {
        List<Project> projects = projectRepository.findAll();
        if (projects.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(projects);
    }
    
    // GET single project
    @GetMapping("/{id}")
    public ResponseEntity<Project> getProject(@PathVariable Long id) {
        return projectRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    // CREATE new project (Universities can add their own projects)
    @PostMapping
    public ResponseEntity<?> createProject(@RequestBody Project project) {

        if (project.getName() == null || project.getName().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Project name is required"));
        }
        if (project.getBaselineKwh() == null || project.getBaselineKwh() <= 0) {
            return ResponseEntity.badRequest().body(Map.of("error", "Valid baseline kWh is required"));
        }
        if (project.getTargetKwh() == null || project.getTargetKwh() <= 0) {
            return ResponseEntity.badRequest().body(Map.of("error", "Valid target kWh is required"));
        }
        
        // Set default values if not provided
        if (project.getStartDate() == null) {
            project.setStartDate(LocalDate.now());
        }
        if (project.getBudget() == null) {
            project.setBudget(0.0);
        }
        if (project.getBudgetUsed() == null) {
            project.setBudgetUsed(0.0);
        }
        if (project.getCategory() == null) {
            project.setCategory("Energy Efficiency");
        }
        
        try {
            Project savedProject = projectRepository.save(project);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedProject);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to create project: " + e.getMessage()));
        }
    }
    
    // UPDATE project details
    @PutMapping("/{id}")
    public ResponseEntity<?> updateProject(@PathVariable Long id, @RequestBody Project projectDetails) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Project project = projectOpt.get();
        
        // Update fields if provided
        if (projectDetails.getName() != null) project.setName(projectDetails.getName());
        if (projectDetails.getCategory() != null) project.setCategory(projectDetails.getCategory());
        if (projectDetails.getBaselineKwh() != null) project.setBaselineKwh(projectDetails.getBaselineKwh());
        if (projectDetails.getTargetKwh() != null) project.setTargetKwh(projectDetails.getTargetKwh());
        if (projectDetails.getTargetDate() != null) project.setTargetDate(projectDetails.getTargetDate());
        if (projectDetails.getStartDate() != null) project.setStartDate(projectDetails.getStartDate());
        if (projectDetails.getBudget() != null) project.setBudget(projectDetails.getBudget());
        if (projectDetails.getBudgetUsed() != null) project.setBudgetUsed(projectDetails.getBudgetUsed());
        if (projectDetails.getInterventionType() != null) project.setInterventionType(projectDetails.getInterventionType());
        
        try {
            Project updatedProject = projectRepository.save(project);
            return ResponseEntity.ok(updatedProject);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to update project: " + e.getMessage()));
        }
    }
    
    // DELETE project
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProject(@PathVariable Long id) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        try {
           
            List<Reading> readings = readingRepository.findByProjectIdOrderByDateAsc(id);
            readingRepository.deleteAll(readings);
            
            
            projectRepository.deleteById(id);
            
            return ResponseEntity.ok(Map.of("message", "Project deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to delete project: " + e.getMessage()));
        }
    }
    
    // GET predictions
    @GetMapping("/{id}/predictions")
    public ResponseEntity<Map<String, Object>> getPredictions(@PathVariable Long id) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Project project = projectOpt.get();
        List<Reading> readings = readingRepository.findByProjectIdOrderByDateAsc(id);
        
        PredictionResult result = predictionService.predictProjectImpact(project, readings);
        
        Map<String, Object> response = new HashMap<>();
        response.put("projectId", project.getId());
        response.put("projectName", project.getName());
        response.put("category", project.getCategory());
        response.put("baselineKwh", project.getBaselineKwh());
        response.put("targetKwh", project.getTargetKwh());
        response.put("targetDate", project.getTargetDate());
        response.put("startDate", project.getStartDate());
        response.put("budget", project.getBudget());
        response.put("budgetUsed", project.getBudgetUsed());
        response.put("confidenceScore", result.getConfidenceScore());
        response.put("recommendation", result.getRecommendation());
        response.put("targetMet", result.isTargetMet());
        response.put("totalReadings", readings.size());
        
        if (readings.size() < 3) {
            response.put("dataQualityWarning", "⚠️ Insufficient data. Add at least 3 months of readings for reliable predictions.");
        }
        
        
        Map<String, Object> metrics = new HashMap<>();
        if (result.getMetrics() != null) {
            for (Map.Entry<Integer, PredictionMetric> entry : result.getMetrics().entrySet()) {
                PredictionMetric m = entry.getValue();
                Map<String, Object> metricMap = new HashMap<>();
                metricMap.put("months", m.getMonths());
                metricMap.put("predictedKwh", Math.round(m.getPredictedKwh() * 10) / 10.0);
                metricMap.put("kwhSaved", Math.round(m.getKwhSaved() * 10) / 10.0);
                metricMap.put("co2eAvoided", Math.round(m.getCo2eAvoided() * 10) / 10.0);
                metricMap.put("costSaved", Math.round(m.getCostSaved() * 10) / 10.0);
                metricMap.put("percentVsBaseline", Math.round(m.getPercentVsBaseline() * 10) / 10.0);
                metrics.put(entry.getKey() + "Month", metricMap);
            }
        }
        response.put("metrics", metrics);
        
        // Generate historical data points for graph
        List<Map<String, Object>> historicalData = new ArrayList<>();
        for (Reading r : readings) {
            Map<String, Object> point = new HashMap<>();
            point.put("date", r.getDate().toString());
            point.put("kwhUsed", r.getKwhUsed());
            point.put("co2eEmissions", r.getCo2eEmissions());
            point.put("cost", r.getCost());
            point.put("occupancy", r.getOccupancy());
            historicalData.add(point);
        }
        response.put("historicalData", historicalData);
        
        // Add summary statistics
        if (!readings.isEmpty()) {
            DoubleSummaryStatistics stats = readings.stream()
                .mapToDouble(Reading::getKwhUsed)
                .summaryStatistics();
            Map<String, Object> summary = new HashMap<>();
            summary.put("avgKwhUsed", Math.round(stats.getAverage() * 10) / 10.0);
            summary.put("minKwhUsed", Math.round(stats.getMin() * 10) / 10.0);
            summary.put("maxKwhUsed", Math.round(stats.getMax() * 10) / 10.0);
            summary.put("totalKwhSaved", calculateTotalKwhSaved(project, readings));
            response.put("summary", summary);
        }
        
        return ResponseEntity.ok(response);
    }
    
    // ADD single reading
    @PostMapping("/{id}/readings")
    public ResponseEntity<?> addReading(@PathVariable Long id, @RequestBody Reading reading) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        
        if (reading.getDate() == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Date is required"));
        }
        if (reading.getKwhUsed() == null || reading.getKwhUsed() <= 0) {
            return ResponseEntity.badRequest().body(Map.of("error", "Valid kWh usage is required"));
        }
        
        Project project = projectOpt.get();
        reading.setProject(project);
        
        // Auto-calculate CO2 and cost if not provided
        if (reading.getCo2eEmissions() == null) {
            reading.setCo2eEmissions(reading.getKwhUsed() * 0.00052);
        }
        if (reading.getCost() == null) {
            reading.setCost(reading.getKwhUsed() * 2.50);
        }
        
        try {
            Reading savedReading = readingRepository.save(reading);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedReading);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to add reading: " + e.getMessage()));
        }
    }
    
    // BULK upload readings (for CSV/Excel data)
    @PostMapping("/{id}/readings/bulk")
    public ResponseEntity<?> addBulkReadings(@PathVariable Long id, @RequestBody List<Reading> readings) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Project project = projectOpt.get();
        List<Reading> savedReadings = new ArrayList<>();
        List<String> errors = new ArrayList<>();
        
        for (int i = 0; i < readings.size(); i++) {
            Reading reading = readings.get(i);
            try {
             
                if (reading.getDate() == null) {
                    errors.add("Row " + (i + 1) + ": Missing date");
                    continue;
                }
                if (reading.getKwhUsed() == null || reading.getKwhUsed() <= 0) {
                    errors.add("Row " + (i + 1) + ": Invalid kWh value");
                    continue;
                }
                
                reading.setProject(project);
                if (reading.getCo2eEmissions() == null) {
                    reading.setCo2eEmissions(reading.getKwhUsed() * 0.00052);
                }
                if (reading.getCost() == null) {
                    reading.setCost(reading.getKwhUsed() * 2.50);
                }
                
                savedReadings.add(readingRepository.save(reading));
            } catch (Exception e) {
                errors.add("Row " + (i + 1) + ": " + e.getMessage());
            }
        }
        
        Map<String, Object> response = new HashMap<>();
        response.put("successCount", savedReadings.size());
        response.put("errorCount", errors.size());
        if (!errors.isEmpty()) {
            response.put("errors", errors);
        }
        response.put("message", "Added " + savedReadings.size() + " of " + readings.size() + " readings");
        
        return ResponseEntity.ok(response);
    }
    
    // UPDATE a reading
    @PutMapping("/{id}/readings/{readingId}")
    public ResponseEntity<?> updateReading(@PathVariable Long id, @PathVariable Long readingId, 
                                           @RequestBody Reading readingDetails) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Optional<Reading> readingOpt = readingRepository.findById(readingId);
        if (readingOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Reading reading = readingOpt.get();
        
        if (readingDetails.getDate() != null) reading.setDate(readingDetails.getDate());
        if (readingDetails.getKwhUsed() != null) {
            reading.setKwhUsed(readingDetails.getKwhUsed());
            reading.setCo2eEmissions(readingDetails.getKwhUsed() * 0.00052);
            reading.setCost(readingDetails.getKwhUsed() * 2.50);
        }
        if (readingDetails.getOccupancy() != null) reading.setOccupancy(readingDetails.getOccupancy());
        
        try {
            Reading updatedReading = readingRepository.save(reading);
            return ResponseEntity.ok(updatedReading);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to update reading: " + e.getMessage()));
        }
    }
    
    // DELETE a reading
    @DeleteMapping("/{id}/readings/{readingId}")
    public ResponseEntity<?> deleteReading(@PathVariable Long id, @PathVariable Long readingId) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Optional<Reading> readingOpt = readingRepository.findById(readingId);
        if (readingOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        try {
            readingRepository.deleteById(readingId);
            return ResponseEntity.ok(Map.of("message", "Reading deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to delete reading: " + e.getMessage()));
        }
    }
    
    // GET project statistics
    @GetMapping("/{id}/statistics")
    public ResponseEntity<Map<String, Object>> getProjectStatistics(@PathVariable Long id) {
        Optional<Project> projectOpt = projectRepository.findById(id);
        if (projectOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Project project = projectOpt.get();
        List<Reading> readings = readingRepository.findByProjectIdOrderByDateAsc(id);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("projectName", project.getName());
        stats.put("totalReadings", readings.size());
        
        if (!readings.isEmpty()) {
            DoubleSummaryStatistics kwhStats = readings.stream()
                .mapToDouble(Reading::getKwhUsed)
                .summaryStatistics();
            
            stats.put("avgKwhUsed", Math.round(kwhStats.getAverage() * 10) / 10.0);
            stats.put("minKwhUsed", Math.round(kwhStats.getMin() * 10) / 10.0);
            stats.put("maxKwhUsed", Math.round(kwhStats.getMax() * 10) / 10.0);
            stats.put("latestKwhUsed", readings.get(readings.size() - 1).getKwhUsed());
            stats.put("latestDate", readings.get(readings.size() - 1).getDate().toString());
        }
        
        double progressToTarget = ((project.getBaselineKwh() - 
            (readings.isEmpty() ? project.getBaselineKwh() : readings.get(readings.size() - 1).getKwhUsed())) / 
            (project.getBaselineKwh() - project.getTargetKwh())) * 100;
        stats.put("progressToTarget", Math.round(Math.min(100, Math.max(0, progressToTarget))));
        
        double budgetProgress = (project.getBudgetUsed() / project.getBudget()) * 100;
        stats.put("budgetProgress", Math.round(Math.min(100, budgetProgress)));
        
        return ResponseEntity.ok(stats);
    }
    
   
    private double calculateTotalKwhSaved(Project project, List<Reading> readings) {
        if (readings.isEmpty()) return 0;
        
        double baselineAvg = project.getBaselineKwh();
        double totalSaved = 0;
        
        for (Reading reading : readings) {
            if (reading.getDate().isAfter(project.getStartDate())) {
                totalSaved += Math.max(0, baselineAvg - reading.getKwhUsed());
            }
        }
        return Math.round(totalSaved * 10) / 10.0;
    }
}