package com.sustainability.impact_predictor.config;

import com.sustainability.impact_predictor.models.*;
import com.sustainability.impact_predictor.repositories.ProjectRepository;
import com.sustainability.impact_predictor.repositories.ReadingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

//@Component
public class DataLoader implements CommandLineRunner{
  
   private ProjectRepository projectRepository;
    
    @Autowired
    private ReadingRepository readingRepository;
    
    @Override
    public void run(String... args) throws Exception {
        if (projectRepository.count() == 0) {
            // Create LED Retrofit project
            Project ledProject = new Project();
            ledProject.setName("LED Retrofit - Admin Block");
            ledProject.setCategory("Energy Efficiency");
            ledProject.setBaselineKwh(120.0);
            ledProject.setTargetKwh(75.0);
            ledProject.setTargetDate(LocalDate.of(2026, 12, 31));
            ledProject.setStartDate(LocalDate.of(2025, 1, 15));
            ledProject.setBudget(250000.0);
            ledProject.setBudgetUsed(150000.0);
            ledProject.setInterventionType("Lighting Retrofit");
            
            Project saved = projectRepository.save(ledProject);
            
            // Add readings (pre and post intervention)
            LocalDate startDate = LocalDate.of(2024, 10, 1);
            for (int i = 0; i < 10; i++) {
                Reading reading = new Reading();
                reading.setDate(startDate.plusMonths(i));
                reading.setProject(saved);
                
                if (i < 4) { // Pre-intervention
                    reading.setKwhUsed(118.0 + Math.random() * 8);
                } else { // Post-intervention
                    double reduction = 120.0 * (1 - (i-3) * 0.08);
                    reading.setKwhUsed(Math.max(70, reduction + (Math.random() * 8 - 4)));
                }
                reading.setCo2eEmissions(reading.getKwhUsed() * 0.00052);
                reading.setCost(reading.getKwhUsed() * 2.50);
                reading.setOccupancy(180 + (int)(Math.random() * 40));
                
                readingRepository.save(reading);
            }
        }
    }
}
