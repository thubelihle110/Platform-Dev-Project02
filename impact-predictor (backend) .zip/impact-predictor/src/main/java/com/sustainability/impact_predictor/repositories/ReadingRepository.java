package com.sustainability.impact_predictor.repositories;

import com.sustainability.impact_predictor.models.Reading;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReadingRepository extends JpaRepository<Reading, Long> {
   List<Reading> findByProjectIdOrderByDateAsc(Long projectId);
}
