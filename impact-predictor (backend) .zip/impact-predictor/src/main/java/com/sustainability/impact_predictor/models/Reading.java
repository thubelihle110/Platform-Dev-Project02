package com.sustainability.impact_predictor.models;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDate;

@Entity
public class Reading {
  @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private LocalDate date;
    private Double kwhUsed;
    private Double co2eEmissions;
    private Double cost;
    private Integer occupancy;
    
    @ManyToOne
    @JoinColumn(name = "project_id")
    @JsonIgnore  // Add this to break the infinite recursion
    private Project project;
    
    // Getters and setters remain the same
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public Double getKwhUsed() { return kwhUsed; }
    public void setKwhUsed(Double kwhUsed) { this.kwhUsed = kwhUsed; }
    public Double getCo2eEmissions() { return co2eEmissions; }
    public void setCo2eEmissions(Double co2eEmissions) { this.co2eEmissions = co2eEmissions; }
    public Double getCost() { return cost; }
    public void setCost(Double cost) { this.cost = cost; }
    public Integer getOccupancy() { return occupancy; }
    public void setOccupancy(Integer occupancy) { this.occupancy = occupancy; }
    public Project getProject() { return project; }
    public void setProject(Project project) { this.project = project; }
}
